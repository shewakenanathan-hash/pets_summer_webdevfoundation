// Change this to http://localhost:4100/api when using the local backend.
const API_BASE_URL = "https://quiz-nydl-special.vercel.app/api";
