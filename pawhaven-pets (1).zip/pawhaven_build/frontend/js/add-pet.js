const form = document.querySelector("#pet-form");
const submitButton = document.querySelector("#submit-button");
const formMessage = document.querySelector("#form-message");
const imageUrlInput = document.querySelector("#imageUrl");
const imagePreview = document.querySelector("#image-preview");
const previewPlaceholder = document.querySelector("#preview-placeholder");

document.addEventListener("DOMContentLoaded", () => {
  form.addEventListener("submit", handleSubmit);
  imageUrlInput.addEventListener("input", updatePreview);
  updatePreview();
});

async function handleSubmit(event) {
  event.preventDefault();
  clearErrors();
  hideMessage();

  const payload = readForm();
  const errors = validate(payload);

  if (Object.keys(errors).length) {
    showErrors(errors);
    return;
  }

  setSubmitting(true);

  try {
    const response = await fetch(`${API_BASE_URL}/pets`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      throw new Error(data?.error || "The pet could not be added.");
    }

    if (!data?._id) throw new Error("The server did not return the new pet ID.");

    window.location.href = `pet-details.html?id=${encodeURIComponent(data._id)}`;
  } catch (error) {
    showMessage(error.message || "Couldn't reach the server. Please try again.");
    setSubmitting(false);
  }
}

function readForm() {
  return {
    name: document.querySelector("#name").value.trim(),
    species: document.querySelector("#species").value,
    breed: document.querySelector("#breed").value.trim(),
    age: Number(document.querySelector("#age").value),
    gender: document.querySelector("#gender").value,
    size: document.querySelector("#size").value,
    description: document.querySelector("#description").value.trim(),
    imageUrl: imageUrlInput.value.trim(),
    status: document.querySelector("#status").value
  };
}

function validate(data) {
  const errors = {};
  if (!data.name) errors.name = "Please enter a name.";
  if (!data.species) errors.species = "Please choose a species.";
  if (!Number.isFinite(data.age) || data.age < 0) errors.age = "Age must be a non-negative number.";
  if (!data.description) errors.description = "Please add a short description.";
  if (!isValidUrl(data.imageUrl)) errors.imageUrl = "Please enter a valid http:// or https:// image URL.";
  return errors;
}

function isValidUrl(value) {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol);
  } catch {
    return false;
  }
}

function showErrors(errors) {
  Object.entries(errors).forEach(([field, message]) => {
    const error = document.querySelector(`[data-error-for="${field}"]`);
    if (error) error.textContent = message;
    const input = document.querySelector(`#${field}`);
    if (input) input.setAttribute("aria-invalid", "true");
  });
  const first = Object.keys(errors)[0];
  document.querySelector(`#${first}`)?.focus();
}

function clearErrors() {
  document.querySelectorAll(".field-error").forEach(el => el.textContent = "");
  form.querySelectorAll("[aria-invalid]").forEach(el => el.removeAttribute("aria-invalid"));
}

function updatePreview() {
  const value = imageUrlInput.value.trim();
  if (!isValidUrl(value)) {
    imagePreview.classList.add("is-hidden");
    previewPlaceholder.classList.remove("is-hidden");
    return;
  }
  imagePreview.src = value;
  imagePreview.classList.remove("is-hidden");
  previewPlaceholder.classList.add("is-hidden");
  imagePreview.onerror = () => {
    imagePreview.classList.add("is-hidden");
    previewPlaceholder.classList.remove("is-hidden");
    previewPlaceholder.textContent = "This image URL could not be previewed.";
  };
}

function setSubmitting(isSubmitting) {
  submitButton.disabled = isSubmitting;
  submitButton.textContent = isSubmitting ? "Adding pet…" : "Add pet →";
}

function showMessage(message) {
  formMessage.textContent = message;
  formMessage.classList.remove("is-hidden");
}

function hideMessage() { formMessage.classList.add("is-hidden"); }
