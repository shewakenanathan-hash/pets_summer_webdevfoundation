const petGrid = document.querySelector("#pet-grid");
const recentGrid = document.querySelector("#recent-grid");
const recentSection = document.querySelector("#recent-section");
const listState = document.querySelector("#list-state");
const petCount = document.querySelector("#pet-count");
const searchInput = document.querySelector("#search-input");
const speciesFilter = document.querySelector("#species-filter");
const statusFilter = document.querySelector("#status-filter");
const sortFilter = document.querySelector("#sort-filter");

let allPets = [];
let searchTimer;

document.addEventListener("DOMContentLoaded", () => {
  loadPets();
  searchInput.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(loadPets, 350);
  });
  speciesFilter.addEventListener("change", loadPets);
  statusFilter.addEventListener("change", loadPets);
  sortFilter.addEventListener("change", () => renderPets(allPets));
});

async function loadPets() {
  setState("loading", "Finding pets…");
  petGrid.innerHTML = "";

  const params = new URLSearchParams();
  const search = searchInput.value.trim();
  if (search) params.set("search", search);
  if (speciesFilter.value) params.set("species", speciesFilter.value);
  if (statusFilter.value) params.set("status", statusFilter.value);

  try {
    const response = await fetch(`${API_BASE_URL}/pets?${params.toString()}`);
    const data = await response.json().catch(() => null);

    if (!response.ok) {
      throw new Error(data?.error || "The server returned an error.");
    }

    allPets = Array.isArray(data) ? data : [];
    renderPets(allPets);
    renderRecent(allPets);
  } catch (error) {
    allPets = [];
    petCount.textContent = "";
    recentSection.classList.add("is-hidden");
    setState("error", "Couldn't reach the server. Please check the API connection and try again.");
  }
}

function renderPets(pets) {
  const sorted = [...pets].sort((a, b) => {
    if (sortFilter.value === "youngest") return Number(a.age) - Number(b.age);
    if (sortFilter.value === "name") return a.name.localeCompare(b.name);
    return 0;
  });

  if (!sorted.length) {
    petCount.textContent = "0 pets";
    setState("empty", "No pets match those filters. Try a different search or filter.");
    return;
  }

  hideState();
  petCount.textContent = `${sorted.length} ${sorted.length === 1 ? "pet" : "pets"}`;
  petGrid.innerHTML = sorted.map(petCard).join("");
}

function renderRecent(pets) {
  const recent = [...pets].sort((a, b) => {
    const dateA = new Date(a.createdAt || 0).getTime();
    const dateB = new Date(b.createdAt || 0).getTime();
    return dateB - dateA;
  }).slice(0, 3);

  if (!recent.length) {
    recentSection.classList.add("is-hidden");
    return;
  }

  recentSection.classList.remove("is-hidden");
  recentGrid.innerHTML = recent.map(pet => `
    <a class="recent-card" href="pet-details.html?id=${encodeURIComponent(pet._id)}">
      <img src="${safeUrl(pet.imageUrl)}" alt="${escapeHtml(pet.name)}" loading="lazy"
           onerror="this.src='https://picsum.photos/seed/pawhaven-fallback/640/480'">
      <span>
        <h3>${escapeHtml(pet.name)}</h3>
        <p>${escapeHtml(pet.species)} · ${escapeHtml(pet.breed || "Mixed breed")}</p>
      </span>
    </a>
  `).join("");
}

function petCard(pet) {
  const statusClass = `status-${String(pet.status || "Available").toLowerCase()}`;
  return `
    <article class="pet-card">
      <a href="pet-details.html?id=${encodeURIComponent(pet._id)}" aria-label="View ${escapeHtml(pet.name)}'s profile">
        <div class="pet-card-image">
          <img src="${safeUrl(pet.imageUrl)}" alt="${escapeHtml(pet.name)}" loading="lazy"
               onerror="this.src='https://picsum.photos/seed/pawhaven-fallback/640/480'">
          <span class="status-badge ${statusClass}">${escapeHtml(pet.status || "Available")}</span>
        </div>
        <div class="pet-card-body">
          <h3>${escapeHtml(pet.name)}</h3>
          <p class="pet-card-meta">${escapeHtml(pet.breed || "Mixed breed")} · ${formatAge(pet.age)}</p>
          <p class="pet-card-description">${escapeHtml(pet.description || "")}</p>
          <span class="text-link">View profile →</span>
        </div>
      </a>
    </article>
  `;
}

function setState(type, message) {
  listState.className = "state-box";
  listState.textContent = message;
  if (type === "error") listState.classList.add("error-state");
  if (type === "empty") listState.classList.add("empty-state");
}

function hideState() { listState.classList.add("is-hidden"); }

function formatAge(age) {
  const n = Number(age);
  return `${n} ${n === 1 ? "year" : "years"} old`;
}

function safeUrl(url) {
  try {
    const parsed = new URL(url);
    return ["http:", "https:"].includes(parsed.protocol) ? parsed.href : "https://picsum.photos/seed/pawhaven-fallback/640/480";
  } catch {
    return "https://picsum.photos/seed/pawhaven-fallback/640/480";
  }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}
