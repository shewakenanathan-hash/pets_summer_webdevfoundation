const petId = new URLSearchParams(location.search).get("id");
const detailState = document.querySelector("#detail-state");
const petProfile = document.querySelector("#pet-profile");
const editSection = document.querySelector("#edit-section");
const editForm = document.querySelector("#edit-form");
const deletePanel = document.querySelector("#delete-panel");
const editMessage = document.querySelector("#edit-message");
const saveEditButton = document.querySelector("#save-edit");
const editPreview = document.querySelector("#edit-preview");

let currentPet = null;

document.addEventListener("DOMContentLoaded", () => {
  if (!petId) {
    showDetailError("No pet ID was provided. Return to the pet list and choose a profile.");
    return;
  }

  loadPet();

  editForm.addEventListener("submit", savePet);
  document.querySelector("#cancel-edit").addEventListener("click", cancelEdit);
  document.querySelector("#cancel-delete").addEventListener("click", () => {
    deletePanel.classList.add("is-hidden");
  });
  document.querySelector("#confirm-delete").addEventListener("click", deletePet);
  document.querySelector("#edit-imageUrl").addEventListener("input", updateEditPreview);
});

async function loadPet() {
  showDetailLoading();

  try {
    const response = await fetch(`${API_BASE_URL}/pets/${encodeURIComponent(petId)}`);
    const data = await response.json().catch(() => null);

    if (!response.ok) throw new Error(data?.error || "Pet not found.");

    currentPet = data;
    renderProfile(data);
    fillEditForm(data);
  } catch (error) {
    showDetailError(error.message || "Couldn't reach the server. Please try again.");
  }
}

function renderProfile(pet) {
  detailState.classList.add("is-hidden");
  petProfile.classList.remove("is-hidden");

  const status = pet.status || "Available";
  const statusClass = `status-${status.toLowerCase()}`;

  petProfile.innerHTML = `
    <div class="profile-image">
      <img src="${safeUrl(pet.imageUrl)}" alt="${escapeHtml(pet.name)}"
           onerror="this.src='https://picsum.photos/seed/pawhaven-fallback/640/480'">
    </div>
    <div class="profile-content">
      <div class="profile-title-row">
        <div>
          <p class="eyebrow">${escapeHtml(pet.species)}</p>
          <h1>${escapeHtml(pet.name)}</h1>
          <p class="profile-breed">${escapeHtml(pet.breed || "Mixed breed")}</p>
        </div>
        <span class="status-badge ${statusClass}">${escapeHtml(status)}</span>
      </div>

      <p class="profile-description">${escapeHtml(pet.description)}</p>

      <div class="pet-facts">
        <div class="pet-fact"><span>Age</span><strong>${formatAge(pet.age)}</strong></div>
        <div class="pet-fact"><span>Gender</span><strong>${escapeHtml(pet.gender || "Unknown")}</strong></div>
        <div class="pet-fact"><span>Size</span><strong>${escapeHtml(pet.size || "Medium")}</strong></div>
      </div>

      <div class="profile-actions">
        <button class="button" id="edit-button" type="button">Edit profile</button>
        ${status !== "Adopted" ? '<button class="button button-ghost" id="adopt-button" type="button">♡ Mark as adopted</button>' : ""}
        <button class="button button-ghost" id="delete-button" type="button">Delete</button>
      </div>
    </div>
  `;

  document.querySelector("#edit-button").addEventListener("click", () => {
    editSection.classList.remove("is-hidden");
    editSection.scrollIntoView({ behavior: "smooth", block: "start" });
  });

  document.querySelector("#delete-button").addEventListener("click", () => {
    deletePanel.classList.remove("is-hidden");
    deletePanel.scrollIntoView({ behavior: "smooth", block: "center" });
  });

  document.querySelector("#adopt-button")?.addEventListener("click", markAdopted);
}

async function markAdopted() {
  const button = document.querySelector("#adopt-button");
  if (!button) return;
  button.disabled = true;
  button.textContent = "Updating…";

  try {
    const response = await fetch(`${API_BASE_URL}/pets/${encodeURIComponent(petId)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "Adopted" })
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(data?.error || "Could not update adoption status.");
    currentPet = data;
    renderProfile(data);
    fillEditForm(data);
  } catch (error) {
    button.disabled = false;
    button.textContent = "♡ Mark as adopted";
    showInlineError(error.message || "Couldn't reach the server.");
  }
}

function fillEditForm(pet) {
  setValue("edit-name", pet.name);
  setValue("edit-species", pet.species);
  setValue("edit-breed", pet.breed || "");
  setValue("edit-age", pet.age);
  setValue("edit-gender", pet.gender || "Unknown");
  setValue("edit-size", pet.size || "Medium");
  setValue("edit-status", pet.status || "Available");
  setValue("edit-imageUrl", pet.imageUrl);
  setValue("edit-description", pet.description);
  updateEditPreview();
}

async function savePet(event) {
  event.preventDefault();
  clearEditErrors();
  hideEditMessage();

  const payload = {
    name: valueOf("edit-name"),
    species: valueOf("edit-species"),
    breed: valueOf("edit-breed"),
    age: Number(valueOf("edit-age")),
    gender: valueOf("edit-gender"),
    size: valueOf("edit-size"),
    status: valueOf("edit-status"),
    imageUrl: valueOf("edit-imageUrl"),
    description: valueOf("edit-description")
  };

  const errors = validate(payload);
  if (Object.keys(errors).length) {
    showEditErrors(errors);
    return;
  }

  saveEditButton.disabled = true;
  saveEditButton.textContent = "Saving…";

  try {
    const response = await fetch(`${API_BASE_URL}/pets/${encodeURIComponent(petId)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(data?.error || "The pet could not be updated.");

    currentPet = data;
    renderProfile(data);
    fillEditForm(data);
    editSection.classList.add("is-hidden");
    showInlineNotice("Profile updated successfully.");
  } catch (error) {
    showEditMessage(error.message || "Couldn't reach the server. Please try again.");
  } finally {
    saveEditButton.disabled = false;
    saveEditButton.textContent = "Save changes";
  }
}

async function deletePet() {
  const button = document.querySelector("#confirm-delete");
  button.disabled = true;
  button.textContent = "Deleting…";

  try {
    const response = await fetch(`${API_BASE_URL}/pets/${encodeURIComponent(petId)}`, { method: "DELETE" });
    if (!response.ok) {
      const data = await response.json().catch(() => null);
      throw new Error(data?.error || "The pet could not be deleted.");
    }
    window.location.href = "index.html";
  } catch (error) {
    button.disabled = false;
    button.textContent = "Yes, delete";
    showInlineError(error.message || "Couldn't reach the server. Please try again.");
  }
}

function validate(data) {
  const errors = {};
  if (!data.name) errors.name = "Please enter a name.";
  if (!data.species) errors.species = "Please choose a species.";
  if (!Number.isFinite(data.age) || data.age < 0) errors.age = "Age must be a non-negative number.";
  if (!data.description) errors.description = "Please add a short description.";
  if (!isValidUrl(data.imageUrl)) errors.imageUrl = "Please enter a valid http:// or https:// image URL.";
  return errors;
}

function showEditErrors(errors) {
  Object.entries(errors).forEach(([field, message]) => {
    const error = editForm.querySelector(`[data-error-for="${field}"]`);
    if (error) error.textContent = message;
    const input = document.querySelector(`#edit-${field}`);
    if (input) input.setAttribute("aria-invalid", "true");
  });
  document.querySelector(`#edit-${Object.keys(errors)[0]}`)?.focus();
}

function clearEditErrors() {
  editForm.querySelectorAll(".field-error").forEach(el => el.textContent = "");
  editForm.querySelectorAll("[aria-invalid]").forEach(el => el.removeAttribute("aria-invalid"));
}

function updateEditPreview() {
  const value = valueOf("edit-imageUrl");
  if (!isValidUrl(value)) {
    editPreview.classList.add("is-hidden");
    return;
  }
  editPreview.src = value;
  editPreview.classList.remove("is-hidden");
}

function cancelEdit() {
  fillEditForm(currentPet);
  clearEditErrors();
  hideEditMessage();
  editSection.classList.add("is-hidden");
}

function showDetailLoading() {
  detailState.className = "state-box";
  detailState.textContent = "Loading pet profile…";
  petProfile.classList.add("is-hidden");
}

function showDetailError(message) {
  detailState.className = "state-box error-state";
  detailState.textContent = message;
  petProfile.classList.add("is-hidden");
}

function showInlineError(message) {
  editMessage.textContent = message;
  editMessage.className = "form-message";
}

function showInlineNotice(message) {
  editMessage.textContent = message;
  editMessage.className = "form-message";
  editMessage.style.background = "var(--green-100)";
  editMessage.style.color = "var(--green-900)";
}

function showEditMessage(message) {
  editMessage.textContent = message;
  editMessage.className = "form-message";
  editMessage.style.background = "";
  editMessage.style.color = "";
}

function hideEditMessage() {
  editMessage.classList.add("is-hidden");
  editMessage.style.background = "";
  editMessage.style.color = "";
}

function valueOf(id) { return document.querySelector(`#${id}`).value.trim(); }
function setValue(id, value) { document.querySelector(`#${id}`).value = value ?? ""; }

function isValidUrl(value) {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol);
  } catch {
    return false;
  }
}

function formatAge(age) {
  const n = Number(age);
  return `${n} ${n === 1 ? "year" : "years"} old`;
}

function safeUrl(url) {
  try {
    const parsed = new URL(url);
    return ["http:", "https:"].includes(parsed.protocol) ? parsed.href : "https://picsum.photos/seed/pawhaven-fallback/640/480";
  } catch {
    return "https://picsum.photos/seed/pawhaven-fallback/640/480";
  }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}
