# PawHaven 🐾

PawHaven is a responsive pet-adoption CRUD frontend built with plain HTML, CSS and JavaScript.

## Features

- Browse all pets with search, species and status filters.
- Sort by newest, youngest or name.
- View a full pet profile.
- Add a pet with client-side validation.
- Live photo preview while adding/editing.
- Edit any pet field with `PUT`.
- Mark a pet as adopted with a small `PUT` request.
- Delete a pet with a custom confirmation panel.
- Loading, empty and error states.
- Responsive layout for phone, tablet and desktop.
- Recently added pets section.

## Project structure

```text
pets/
├── instruction.md
├── README.md
├── backend/
└── frontend/
    ├── html/
    │   ├── index.html
    │   ├── add-pet.html
    │   └── pet-details.html
    ├── css/
    │   └── styles.css
    └── js/
        ├── config.js
        ├── index.js
        ├── add-pet.js
        └── pet-details.js
```

## API

The frontend reads the API URL from `frontend/js/config.js`.

For local development:

```js
const API_BASE_URL = "http://localhost:4100/api";
```

For the instructor's deployed API, the project is configured with:

```js
const API_BASE_URL = "https://quiz-nydl-special.vercel.app/api";
```

If your instructor gives you a different deployed API URL, change only `config.js`.

## Run locally

1. Start the PawHaven backend.
2. Open `frontend/html/index.html` with VS Code Live Server.
3. Test the full flow:
   - Browse
   - Add
   - Edit
   - Mark as adopted
   - Delete

## Deployment

The `frontend/` folder can be deployed as a static site on GitHub Pages, Netlify or Vercel.

When using GitHub Pages, set the repository to publish the folder containing the three HTML pages, CSS and JS files. If the repository has extra project folders, use a deployment configuration that publishes the `frontend` folder.

## Live frontend

Add your final deployed frontend URL here before submitting.

`https://YOUR-LIVE-FRONTEND-URL`

## Repository naming

Use the course-required format:

`groupName_batchName_courseName`

Example:

`pets_summer_webdevfoundation`
